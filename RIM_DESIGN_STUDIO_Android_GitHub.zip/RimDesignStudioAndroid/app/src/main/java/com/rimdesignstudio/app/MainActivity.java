package com.rimdesignstudio.app;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.graphics.*;
import android.net.Uri;
import android.provider.MediaStore;
import android.view.*;
import android.widget.*;
import java.io.OutputStream;

public class MainActivity extends Activity {
    private WheelView wheelView;
    private int activeZone = 0; // 0 spokes, 1 lip
    private int selectedColor = Color.BLACK;
    private int spokesColor = Color.BLACK;
    private int lipColor = Color.LTGRAY;
    private boolean erase = false;
    private final int[] colors = {
        Color.rgb(17,17,17), Color.rgb(25,26,35), Color.rgb(177,184,192),
        Color.rgb(83,91,101), Color.rgb(128,85,47), Color.rgb(196,154,50),
        Color.rgb(158,32,40), Color.WHITE
    };
    private final String[] colorNames = {
        "შავი", "შავი მარგალიტი", "ვერცხლისფერი", "გრაფიტი",
        "ბრინჯაო", "ოქროსფერი", "წითელი", "თეთრი"
    };

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        buildScreen();
    }

    private void buildScreen() {
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(14, 12, 14, 12);
        page.setBackgroundColor(Color.rgb(23,26,32));

        TextView title = new TextView(this);
        title.setText("RIM DESIGN STUDIO");
        title.setTextColor(Color.rgb(217,181,109));
        title.setTextSize(23);
        title.setTypeface(null, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        page.addView(title, new LinearLayout.LayoutParams(-1, dp(48)));

        wheelView = new WheelView(this);
        LinearLayout.LayoutParams imageParams = new LinearLayout.LayoutParams(-1, 0, 1);
        imageParams.topMargin = dp(8);
        imageParams.bottomMargin = dp(8);
        page.addView(wheelView, imageParams);

        Button load = button("ფოტოს ჩატვირთვა");
        load.setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            i.setType("image/*");
            i.addCategory(Intent.CATEGORY_OPENABLE);
            startActivityForResult(i, 10);
        });
        page.addView(load);

        TextView zoneLabel = label("შეღებვის ზონა");
        page.addView(zoneLabel);
        LinearLayout zones = new LinearLayout(this);
        Button spokes = button("გულები / სპიცები");
        Button lip = button("გარე კანტი");
        spokes.setOnClickListener(v -> { activeZone = 0; wheelView.invalidate(); });
        lip.setOnClickListener(v -> { activeZone = 1; wheelView.invalidate(); });
        zones.addView(spokes, new LinearLayout.LayoutParams(0, dp(44), 1));
        zones.addView(lip, new LinearLayout.LayoutParams(0, dp(44), 1));
        page.addView(zones);

        page.addView(label("აირჩიე ფერი"));
        Spinner spinner = new Spinner(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, colorNames);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            public void onNothingSelected(android.widget.AdapterView<?> p) {}
            public void onItemSelected(android.widget.AdapterView<?> p, View v, int pos, long id) {
                selectedColor = colors[pos];
                if (activeZone == 0) spokesColor = selectedColor; else lipColor = selectedColor;
                if (wheelView != null) wheelView.invalidate();
            }
        });
        page.addView(spinner);

        LinearLayout tools = new LinearLayout(this);
        Button eraseButton = button("წაშლა: გამორთული");
        eraseButton.setOnClickListener(v -> {
            erase = !erase;
            eraseButton.setText(erase ? "წაშლა: ჩართული" : "წაშლა: გამორთული");
        });
        Button clear = button("მონიშვნის გასუფთავება");
        clear.setOnClickListener(v -> { wheelView.clearActiveMask(); });
        tools.addView(eraseButton, new LinearLayout.LayoutParams(0, dp(44), 1));
        tools.addView(clear, new LinearLayout.LayoutParams(0, dp(44), 1));
        page.addView(tools);

        Button save = button("შეღებილი ფოტოს შენახვა");
        save.setOnClickListener(v -> saveImage());
        page.addView(save);

        TextView hint = label("ფოტოზე თითით გაატარე იმ ნაწილზე, რომლის შეღებვაც გინდა. გულები და კანტი ცალ-ცალკე მონიშნე.");
        hint.setTextSize(12);
        page.addView(hint);

        setContentView(page);
    }

    private TextView label(String s) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextColor(Color.LTGRAY); t.setPadding(2, dp(8), 2, dp(4));
        return t;
    }
    private Button button(String s) {
        Button b = new Button(this);
        b.setText(s); b.setTextSize(12); b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(54,62,74)));
        return b;
    }
    private int dp(int x) { return (int)(x * getResources().getDisplayMetrics().density + 0.5f); }

    @Override protected void onActivityResult(int req, int result, Intent data) {
        super.onActivityResult(req, result, data);
        if (req == 10 && result == RESULT_OK && data != null) {
            try {
                Uri uri = data.getData();
                wheelView.setBitmap(MediaStore.Images.Media.getBitmap(getContentResolver(), uri));
            } catch (Exception e) {
                Toast.makeText(this, "ფოტოს გახსნა ვერ მოხერხდა", Toast.LENGTH_LONG).show();
            }
        }
    }

    private void saveImage() {
        if (wheelView.original == null) {
            Toast.makeText(this, "ჯერ ჩატვირთე დისკის ფოტო", Toast.LENGTH_SHORT).show(); return;
        }
        try {
            Bitmap result = wheelView.makeResult();
            String name = "RimDesign_" + System.currentTimeMillis() + ".png";
            android.content.ContentValues values = new android.content.ContentValues();
            values.put(MediaStore.Images.Media.DISPLAY_NAME, name);
            values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
            values.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/RimDesignStudio");
            Uri uri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
            OutputStream out = getContentResolver().openOutputStream(uri);
            result.compress(Bitmap.CompressFormat.PNG, 100, out);
            out.close();
            Toast.makeText(this, "ფოტო შენახულია გალერეაში", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "შენახვა ვერ მოხერხდა: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    class WheelView extends View {
        Bitmap original;
        Bitmap display;
        Bitmap maskSpokes, maskLip;
        Paint paint = new Paint(3);
        Path currentPath = new Path();
        float downX, downY;
        RectF drawRect = new RectF();

        WheelView(Activity c) {
            super(c);
            setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            setBackgroundColor(Color.rgb(32,36,43));
        }
        void setBitmap(Bitmap b) {
            original = b.copy(Bitmap.Config.ARGB_8888, true);
            maskSpokes = Bitmap.createBitmap(b.getWidth(), b.getHeight(), Bitmap.Config.ARGB_8888);
            maskLip = Bitmap.createBitmap(b.getWidth(), b.getHeight(), Bitmap.Config.ARGB_8888);
            display = original;
            invalidate();
        }
        void clearActiveMask() {
            if (original == null) return;
            Canvas c = new Canvas(activeZone == 0 ? maskSpokes : maskLip);
            c.drawColor(Color.TRANSPARENT, PorterDuff.Mode.CLEAR);
            invalidate();
        }
        Bitmap activeMask() { return activeZone == 0 ? maskSpokes : maskLip; }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            if (original == null) {
                paint.setColor(Color.LTGRAY); paint.setTextSize(dp(16));
                canvas.drawText("ჩატვირთე დისკის ფოტო", dp(24), getHeight()/2f, paint);
                return;
            }
            float scale = Math.min((float)getWidth()/original.getWidth(), (float)getHeight()/original.getHeight());
            float w = original.getWidth()*scale, h = original.getHeight()*scale;
            float x = (getWidth()-w)/2f, y = (getHeight()-h)/2f;
            drawRect.set(x,y,x+w,y+h);
            canvas.drawBitmap(makeResult(), null, drawRect, paint);
            paint.setColor(Color.rgb(217,181,109));
            paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(dp(2));
            canvas.drawRect(drawRect, paint);
            paint.setStyle(Paint.Style.FILL);
            paint.setTextSize(dp(11));
            canvas.drawText(activeZone == 0 ? "აქტიური ზონა: გულები" : "აქტიური ზონა: კანტი", dp(8), dp(18), paint);
        }

        @Override public boolean onTouchEvent(android.view.MotionEvent e) {
            if (original == null) return false;
            float scale = Math.min((float)getWidth()/original.getWidth(), (float)getHeight()/original.getHeight());
            float ox = (getWidth()-original.getWidth()*scale)/2f;
            float oy = (getHeight()-original.getHeight()*scale)/2f;
            float x = (e.getX()-ox)/scale, y = (e.getY()-oy)/scale;
            if (x < 0 || y < 0 || x >= original.getWidth() || y >= original.getHeight()) return true;
            Canvas c = new Canvas(activeMask());
            Paint p = new Paint(3);
            p.setColor(erase ? Color.TRANSPARENT : Color.WHITE);
            p.setStrokeWidth(Math.max(12, 28/scale));
            p.setStrokeCap(Paint.Cap.ROUND); p.setStrokeJoin(Paint.Join.ROUND);
            if (e.getAction() == MotionEvent.ACTION_DOWN) {
                downX=x; downY=y;
                if (erase) {
                    p.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.CLEAR));
                }
                c.drawCircle(x,y,Math.max(8,14/scale),p);
                invalidate(); return true;
            } else if (e.getAction() == MotionEvent.ACTION_MOVE) {
                if (erase) p.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.CLEAR));
                c.drawLine(downX,downY,x,y,p);
                c.drawCircle(x,y,Math.max(8,14/scale),p);
                downX=x; downY=y; invalidate(); return true;
            }
            return true;
        }

        Bitmap makeResult() {
            if (original == null) return null;
            Bitmap out = original.copy(Bitmap.Config.ARGB_8888, true);
            int w = out.getWidth(), h = out.getHeight();
            int[] pixels = new int[w*h], m0 = new int[w*h], m1 = new int[w*h];
            out.getPixels(pixels,0,w,0,0,w,h);
            maskSpokes.getPixels(m0,0,w,0,0,w,h);
            maskLip.getPixels(m1,0,w,0,0,w,h);
            float[] hsv = new float[3], target = new float[3];
            Color.colorToHSV(selectedColor,target);
            for (int i=0;i<pixels.length;i++) {
                boolean s = Color.alpha(m0[i]) > 20;
                boolean l = Color.alpha(m1[i]) > 20;
                if (!s && !l) continue;
                int zoneColor = s ? spokesColor : lipColor;
                Color.colorToHSV(pixels[i],hsv);
                Color.colorToHSV(zoneColor,target);
                hsv[0] = target[0];
                hsv[1] = Math.max(hsv[1], target[1]);
                pixels[i] = Color.HSVToColor(Color.alpha(pixels[i]),hsv);
            }
            out.setPixels(pixels,0,w,0,0,w,h);
            return out;
        }
    }
}
