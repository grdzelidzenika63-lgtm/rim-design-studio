RIM DESIGN STUDIO — Android project

This is an Android Studio source project, not a prebuilt APK.
The current execution environment does not contain Android SDK / Gradle build tools, so an APK could not be compiled here.

Build APK:
1. Install Android Studio on a Windows PC.
2. Open this folder as an existing project.
3. Wait for Gradle sync and install any requested Android SDK Platform 35 / Build Tools.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Android Studio will show the generated APK location (usually app/build/outputs/apk/debug/app-debug.apk).

Current Android prototype:
- Import a wheel photo from phone gallery.
- Choose inner/spoke or outer-lip zone.
- Paint the part with finger; erase unwanted mask.
- Choose a color preset and save PNG to Pictures/RimDesignStudio.

Limitations:
- This initial Android build is manual-brush based. It does not yet include SAM 2 AI segmentation or the Windows app's automatic detection.
- The two zone masks and their selected colors are stored separately.
- The prototype has not been built or tested on a physical Android phone.
